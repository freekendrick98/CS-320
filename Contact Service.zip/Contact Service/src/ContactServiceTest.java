import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
public class ContactServiceTest {

	@Test
	//add new contact to contact list
	void addContact() {
		ContactService contactService = new ContactService();
		
		Contact A1 = new Contact("A100", "Kendrick", "Free", "8371629836", "232 Jupiter St");
		
		assertEquals(true, contactService.addContact(A1));
	}
	@Test
	//populate database and delete contacts bases on ID number
	void deleteContact() {
		ContactService contactService = new ContactService();
		
		Contact A1 = new Contact("A100", "Kendrick", "Free", "8371629836", "232 Jupiter St");
		
		contactService.addContact(A1);
		
		assertEquals(true, contactService.deleteContact("A100"));
	}
	@Test
	//update contacts 
	void contactUpdate() {
		ContactService contactService = new ContactService();
		
		Contact A1 = new Contact("A100", "Kendrick", "Free", "8371629836", "232 Jupiter St");
		
		contactService.addContact(A1);
		
		assertEquals(true, contactService.contactUpdate("A100", "Kenjamin", "Freeman", "9469572639", "232 Jupiter St"));
	}
	
}
	