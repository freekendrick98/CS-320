import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

	
	//accessible by all methods
			Contact contact = new Contact("A100", "Kendrick", "Free", "8371629836", "232 Jupiter St");
			//assertEquals ensures that the strings match or are equal
			void getContactID() {
				assertEquals("A100", contact.getContactID());
			}
			
			void getName() {
				assertEquals("Kendrick",contact.getName());
			}
			
			void getLastName() {
				assertEquals("Free",contact.getLastName());
			}
			
			void getNumber() {
				assertEquals("8371629836",contact.getNumber());
			}
			
			void getaddress() {
				assertEquals("232 Jupiter St",contact.getaddress());
			}
			
			void printResults() {
				System.out.print("");
			}

}
