import java.util.ArrayList;
public class ContactService {
	//Rubric specified that a database was not required but I can't test without something to push and pull data from 
	ArrayList <Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	//Checks to see if contact is present, if not it is given the greenlight and added to the array, otherwise contact is not added.
	public boolean addContact (Contact contact) {
		//boolean used to determine if the contact is already present in the array
		boolean greenLight = false;
		
		for(Contact contactList:contacts) {
			if(contactList.equals(contact)) {
				greenLight = true;
			}
		}
		//If the contact is not present then it is added and the boolean is set to return true
		if(!greenLight) {
			contacts.add(contact);
			return true;
		}
		
		else {
			return false;
		}
		
	}
	//Delete contact based on a given contact ID. Removes it from the array.
	public boolean deleteContact(String contactID) {
		for(Contact contactList:contacts) {
			if(contactList.getContactID().equals(contactID)) {
				contacts.remove(contactList);
				return true;
			}
		}
		
		return false;
		
	}
	//update contact in the array based on the given contact ID. All input will be validated to meet input requirements
	public boolean contactUpdate(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		for(Contact contactList:contacts) {
			if(contactList.getContactID().equals(contactID)) {
				if(!firstName.equals("") & !(firstName.length() > 10)) {
					contactList.setName(firstName);
				}
				
				if(!lastName.equals("") & !(lastName.length() > 10)) {
					contactList.setName(lastName);
				}
				
				if(!phoneNumber.equals("") & (phoneNumber.length() == 10)) {
					contactList.setName(phoneNumber);
				}
				
				if(!address.equals("") & !(address.length() > 30)) {
					contactList.setName(address);
				}
				return true;
				
			}
		}
		
		return false;
		
	}
	
}
