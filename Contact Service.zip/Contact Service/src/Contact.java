
public class Contact {
	//Declare string variables used in Contact class.
	String contactID;
	String firstName;
	String lastName;
	String phoneNumber;
	String Address;
	
	//Input check contactId and declare variables used in the setters
	public Contact(String contactId, String name, String surname, String number, String address){
		if(contactId.length() <= 10 & contactId != null) {
			this.contactID = contactId;
		
		}
		else {
			System.out.println("Please enter valid input.");
		}
		this.setName (name);
		this.setLastName(surname);
		this.setNumber(number);
		this.setAddress(address);
		
	}
	//set name and validate input 	
	public void setName(String name) {
		if(name.length() <= 10 & name != null ) {
			this.firstName = name;
		}
		else {
			System.out.println("Please enter valid input.");
		}
	}
	//set last name and validate input
	public void setLastName(String surname) {
		if(surname.length() <= 10 & surname!= null) {
			this.lastName = surname;
		}
		else {
			System.out.println("Please enter valid input.");
		}
	}
	//set phone number and validate input
	public void setNumber(String number) {
		if(number.length() == 10 & number!= null) {
			this.phoneNumber = number;
		}
		else {
			System.out.println("Please enter valid input.");
		}
	}
	//set address and validate input 
	public void setAddress(String address) {
		if(address.length() <= 30 & address != null) {
			this.Address = address;
		}
		else {
			System.out.println("Please enter valid input.");
		}
	}
	//get contactId value
	public String getContactID() {
		return contactID;
	}
	//get first name string
	public String getName() {
		return firstName;
	}
	//get last name string
	public String getLastName() {
		return lastName;
	} 
	//get phone number string
	public String getNumber() {
		return phoneNumber;
	}
	//get address string
	public String getaddress() {
		return Address;
	}

	
}
